<?php
/** GARRISON MODIFIED 4/20/2013 **/
function to_currency($number)
{
	$CI =& get_instance();
	$currency_symbol = $CI->config->item('currency_symbol') ? $CI->config->item('currency_symbol') : '$';
	if($number >= 0)
	{
		if($CI->config->item('currency_side') !== 'currency_side')
			return $currency_symbol.number_format($number, 2, '.', '');
		else
			return number_format($number, 2, '.', '').$currency_symbol;
	}
    else
    {
    	if($CI->config->item('currency_side') !== 'currency_side')
    		return '-'.$currency_symbol.number_format(abs($number), 2, '.', '');
    	else
    		return '-'.number_format(abs($number), 2, '.', '').$currency_symbol;
    }
}
/** END MODIFIED **/

/** ALLEN ADD 10/16/2014 **/
function C_SPACE($a, $b) 
{ 
	$c = $a - strlen($b);
	
	$d = str_repeat('&nbsp;&nbsp;',$c);

	return $d.$b;
}

function to_currency_no_money($number)
{
	return number_format($number, 2, '.', '');
}

function cut_content($a, $b)
{
    $sub_content = mb_substr($a, 0, $b, 'UTF-8'); 
    
	if (strlen($a) > strlen($sub_content)) 
	  $sub_content = $sub_content."...";
	
	return $sub_content;
}
?>