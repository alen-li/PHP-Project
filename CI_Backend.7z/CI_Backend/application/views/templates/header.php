<html>
        <head>
                <title>CodeIgniter Tutorial</title>
        </head>
        <body>

                <h1><?php echo $title; ?></h1>